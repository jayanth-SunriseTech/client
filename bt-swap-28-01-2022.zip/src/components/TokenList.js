let Tokens = [
    {
        "name": " BNB",
        "symbol": "BT  BNB",
        "address": "native",
        "nativeAddress":'0xe66f1e5b77d1817366e9eb99ae419a0c3615baaf',
        "chainId": 97,
        "decimals": 18,
        "logoURI": "https://pancake.kiemtienonline360.com/images/coins/0xae13d989dac2f0debff460ac112a837c89baa7cd.png"
      },
    {
        "name": " BT Token",
        "symbol": "BT  BNB",
        "address": "0x594f4a2e7ba607aa95cb01f7d81b386665a5fb6c",
        "nativeAddress":'0xe66f1e5b77d1817366e9eb99ae419a0c3615baaf',
        "chainId": 97,
        "decimals": 18,
        "logoURI": "https://pancake.kiemtienonline360.com/images/coins/0xae13d989dac2f0debff460ac112a837c89baa7cd.png"
      },
      {
        "name": "BT USD",
        "symbol": "BT USD",
        "address": "0xE747a50e14A61B0b1bfC80Fb1A02750FD44c1715",
        "nativeAddress":'0xe66f1e5b77d1817366e9eb99ae419a0c3615baaf',
        "chainId": 97,
        "decimals": 18,
        "logoURI": "https://pancake.kiemtienonline360.com/images/coins/0x78867bbeef44f2326bf8ddd1941a4439382ef2a7.png"
      },
  
      {
        "name": "BT  ETH ",
        "symbol": "BT ETH",
        "address": "0x68e813d8c435489f0Bfc60FbceAF72E0E6eE8281",
        "chainId": 97,
        "decimals": 18,
        "logoURI": "https://pancake.kiemtienonline360.com/images/coins/0x8babbb98678facc7342735486c851abd7a0d17ca.png"
      },
      {
        "name": " BT DAI ",
        "symbol": "BT DAI",
        "address": "0x0eF2aD6C2327516563015500f1e125Ae907e23A0",
        "chainId": 97,
        "decimals": 18,
        "logoURI": "https://pancake.kiemtienonline360.com/images//coins/0x8a9424745056eb399fd19a0ec26a14316684e274.png"
      },
      {
        "name": "BT  Token",
        "symbol": "BT  Token",
        "address": "0x594f4a2e7ba607aa95cb01f7d81b386665a5fb6c",
        "chainId": 97,
        "decimals": 18,
        "logoURI": "https://pancake.kiemtienonline360.com/images/coins/0xf9f93cf501bfadb6494589cb4b4c15de49e85d0e.png"
      },
      {
        "name": "BT  moon ",
        "symbol": "BT MOON",
        "address": "0x318d44C1E56A55CBd6a5d0795404A0B6429c7fe2",
        "chainId": 97,
        "decimals": 18,
        "logoURI": "https://pancake.kiemtienonline360.com/images/coins/0xdacbdecc2992a63390d108e8507b98c7e2b5584a.png"
      }
    
]

let bnbTokenList = JSON.stringify(Tokens)

let bnb = window.localStorage.setItem('bnb',bnbTokenList)



export default Tokens
